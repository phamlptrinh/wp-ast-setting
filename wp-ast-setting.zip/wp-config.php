<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp-ast-setting' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '3@Ad`aW>fn+[wIU@nBIGC8D0:xf-i4UTyaJ|MD4$<i/5UkT]am4Jui)lzA]BT_U]' );
define( 'SECURE_AUTH_KEY',   '~=mg1X!/Ey}t/@LD,9IV!Hxvz!; P85=x$1cYAP/agjH=,6dej2(|NgxBsZbTU$x' );
define( 'LOGGED_IN_KEY',     'IHc[ 9l]iwCsz a^pJphWc$>0POcTc8k%ia L(paz/mCD7$%C_}Vs_=^+|)&U*u@' );
define( 'NONCE_KEY',         'Rr}5CD$=VnN~+pAk`k$;lJwzQB.RiiJm1 %t$4htP8>s=],8iEP.lj+oDXW_8[:d' );
define( 'AUTH_SALT',         '&6Pm:(r?[rh!Imva?RMC9b#-.8>I.G]`0_K awQUbmf0uEg`KVl8r2yRaL%--ZYC' );
define( 'SECURE_AUTH_SALT',  'C=p/bY+iT_wsAw0kFW/x/gz_+wm3eMAc1c;M-E|RYu_KEHu3/53(mNU|n|+K+>v5' );
define( 'LOGGED_IN_SALT',    '37*uahU,7iv$*5$Rnrz[yV =]nHwT/luScuV7<`ilVWCk@eM/te:!E2oS&yOKD~4' );
define( 'NONCE_SALT',        ')mHZX@44oAsP4?8t]gNxRKMK3o$fBa3!45+ bgS{VpZ6mA7NdImmbh*0)g5X]O>R' );
define( 'WP_CACHE_KEY_SALT', '6~7fR12^irHTqnvmb H].t`PAs?()#?5Ik3k}9DHt$A5K xSFuW w,L2VO!M.Y.&' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
